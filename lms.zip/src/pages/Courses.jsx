import { useState } from "react";
import CourseCard from "../components/CourseCard";
import "../Styles/Courses.css";

function Courses() {
  const [searchTerm, setSearchTerm] = useState("");

  const courses = [
    {
      title: "React Basics",
      description: "Learn React from scratch with hands-on projects",
      level: "Beginner",
    },
    {
      title: "Advanced React",
      description: "Hooks, Context API, performance optimization",
      level: "Advanced",
    },
    {
      title: "Node.js Fundamentals",
      description: "Build backend APIs using Node and Express",
      level: "Intermediate",
    },
    {
      title: "MongoDB Essentials",
      description: "Database design, CRUD, and aggregation",
      level: "Beginner",
    },
    {
      title: "Full Stack Development",
      description: "React + Node + MongoDB full stack project",
      level: "Advanced",
    },
    {
      title: "JavaScript Mastery",
      description: "Deep dive into modern JavaScript concepts",
      level: "Intermediate",
    },
    {
      title: "TypeScript Essentials",
      description: "Learn TypeScript for safer code",
      level: "Intermediate",
    },
    {
      title: "Express.js Mastery",
      description: "Advanced Node.js backend development",
      level: "Advanced",
    },
  ];

  // Filter courses based on search term
  const filteredCourses = courses.filter((course) =>
    course.title.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="courses-container">
      <h2>📚 Available Courses</h2>
      <p className="subtitle">
        Choose from industry-ready courses and start learning today
      </p>

      {/* SEARCH BAR */}
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search courses..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="course-grid">
        {filteredCourses.length > 0 ? (
          filteredCourses.map((course, index) => (
            <CourseCard key={index} course={course} />
          ))
        ) : (
          <p className="no-results">No courses found 😔</p>
        )}
      </div>
    </div>
  );
}

export default Courses;
